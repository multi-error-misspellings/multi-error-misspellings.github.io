import java.io.*;
import java.lang.*;
import java.util.*;


class AuxiliaryMethods{
	
	AuxiliaryMethods(){}
	
	int findMaximumWordLength(String[] wordsArray){
	   int size=0;
	   
	   for(int i=0; i<wordsArray.length; ++i)
	   	   if(wordsArray[i].length() > size)
	   	     size = wordsArray[i].length();
	return size;
	}
	
	
	
	int getCharNumber(char ch) {
	
	   if (ch == 'a')
	     return 0;
           else if(ch =='b')
             return 1;
           else if(ch =='c')
             return 2;
           else if(ch =='d')
             return 3;     
           else if(ch =='e')
             return 4;     	   
           else if(ch =='f')
             return 5;	
           else if(ch =='g')
             return 6;
           else if(ch =='h')
             return 7;
           else if(ch =='i')
             return 8;
           else if(ch =='j')
             return 9;
           else if(ch =='k')
             return 10;
           else if(ch =='l')
             return 11;
           else if(ch =='m')
             return 12;
           else if(ch =='n')
             return 13;
           else if(ch =='o')
             return 14;
           else if(ch =='p')
             return 15;
           else if(ch =='q')
             return 16;
           else if(ch =='r')
             return 17;
           else if(ch =='s')
             return 18;
           else if(ch =='t')
             return 19;
           else if(ch =='u')
             return 20;
           else if(ch =='v')
             return 21;
           else if(ch =='w')
             return 22;
           else if(ch =='x')
             return 23;
           else if(ch =='y')
             return 24;
           else if(ch =='z')
             return 25;     
	return(-1);
	}
	

	int getPosNumber(char ch) {
	
			if (ch == 'a')
			 return 1;
           else if(ch =='b')
             return 2;
           else if(ch =='c')
             return 3;
           else if(ch =='d')
             return 4;     
           else if(ch =='e')
             return 5;     	   
           else if(ch =='f')
             return 6;	
           else if(ch =='g')
             return 7;
           else if(ch =='h')
             return 8;
           else if(ch =='i')
             return 9;
           else if(ch =='j')
             return 10;
           else if(ch =='k')
             return 11;
           else if(ch =='l')
             return 12;
           else if(ch =='m')
             return 13;
           else if(ch =='n')
             return 14;
           else if(ch =='o')
             return 15;
           else if(ch =='p')
             return 16;
           else if(ch =='q')
             return 17;
           else if(ch =='r')
             return 18;
           else if(ch =='s')
             return 19;
           else if(ch =='t')
             return 20;
           else if(ch =='u')
             return 21;
           else if(ch =='v')
             return 22;
           else if(ch =='w')
             return 23;
           else if(ch =='x')
             return 24;
           else if(ch =='y')
             return 25;
           else if(ch =='z')
             return 26;     
	return(-1);
	}
	
	
	int findShortestRows(int[][] u, int[][] l){
	
		int ru = u.length;
		int rl = l.length;
		int shortest=0;
		
		if(ru < rl)
		  shortest = u.length;
	        else 
		  shortest = l.length;
	        	
	 return(shortest);       
	}
	
	
	int findLongestRows(int[][] u, int[][] l){
	
		int ru = u.length;
		int rl = l.length;
		int longest=0;
		
		if(ru > rl)
		  longest = u.length;
	        else 
		  longest = l.length;
	        	
	 return(longest);       
	}
	
	double[][] initialize2D (double[][] arr){
	
		for(int i=0; i<arr.length; ++i)
			for(int j=0; j<arr[0].length; ++j)
			       arr[i][j] = 0;
	   return (arr);	       
	}
	
	void print2D (double[][] arr){
		for(int i=0; i<arr.length; ++i){
			for(int j=0; j<arr[0].length; ++j)
			       System.out.print ( " " + arr[i][j]);
		System.out.println();
		}
	}

	int getConsonantCount (String str){
	
		//string entered is unique chars
		int count=0;
		str = str.toLowerCase();
		
		for(int i=0; i< str.length(); ++i){
			
			if(str.charAt(i) == 'a' ||
			   str.charAt(i) == 'e' ||
			   str.charAt(i) == 'o' ||
			   str.charAt(i) == 'i' ||
			   str.charAt(i) == 'u' ||
			   str.charAt(i) == 'h' ||
			   str.charAt(i) == 'y' ||
			   str.charAt(i) == 'w' )
				
			{}
			else
				++count;
	
	}
	return(count);
	}//ends method
	
	String removeAdjacentDuplicates(String s){
		//remove only char of adjacent duplicates
	    char[] chars = s.toCharArray();
        String str="";
        

        for (int i = 0; i < chars.length; i++) {
        	//initial string 
            if (i == 0 ) {
                 str = String.valueOf(chars[i]);
            } 
            
            // do not add char if same as previous
            else if (i > 0 && chars[i] == chars[i-1] ) {
            	// do nothing
            }
            
            // add char if not same as previous
            else if (i > 0 && chars[i] != chars[i-1] ) {
            	str = str + String.valueOf(chars[i]);
            	
            }	
        }// ends for loop 
        
   
        return (str); 
	}
	
	public static String getConsonantStr (String str){
	
		//string entered is unique chars
		int count=0;
		str = str.toLowerCase();
		String cntstr = "";
		
		for(int i=0; i< str.length(); ++i){
			
			if(str.charAt(i) == 'a' ||
			   str.charAt(i) == 'e' ||
			   str.charAt(i) == 'o' ||
			   str.charAt(i) == 'i' ||
			   str.charAt(i) == 'u' ||
			   str.charAt(i) == 'h' ||
			   str.charAt(i) == 'y' ||
			   str.charAt(i) == 'w' )
				
			{}
			else
				cntstr = cntstr + String.valueOf(str.charAt(i));
	
	}
	return(cntstr);
	}//ends method	
	
	
	String getDistinct (String str) {
		
		String store = "";  // store string
		int count =0;
		for(int i=0; i< str.length(); ++i){
			
			if(i==0)  store += str.charAt(i);
			
			else if (i >0 ){
				
				char ch = str.charAt(i);
				
				//this for loop checks if the char at str exits in the store
				for(int j=0; j<store.length(); ++j){
					//System.out.println("Length: " + store.length());
					if(ch == store.charAt(j))
						break;
					
					else
						++count;
					
				}// ends for j
					
				
				if(count == store.length()){
					store += ch; 
				}
				
				
			}//ends else if i>0		
			
			//System.out.println("the store: " + store);
			count=0;
		}//ends big for i
		
		

	return(store);	
	} // ends getDistinct
	

	String getDistinct2 (String str) {
		
		char[] charr = str.toCharArray();
		
		String st = "";
		for(int i=0; i<charr.length; ++i){
		
			if(i == 0)
			{st = ""+charr[i];
			  
			}
	
			else {
			 
			     if (charr[i] == '1' )
			    		{ if(charr[i-1] =='1') 
			    			{}
			    		 else	
			    		  st+="1";  }
			    
			     if (charr[i] == '2' )
			    		{ if(charr[i-1] =='2') 
			    			{}
			    		 else	
			    		  st+="2";  }

			     if (charr[i] == '3' )
			    		{ if(charr[i-1] =='3') 
			    			{}
			    		 else	
			    		  st+="3";  }

			    if (charr[i] == '4' )
			    		{ if(charr[i-1] =='4') 
			    			{}
			    		 else	
			    		  st+="4";  }

			    if (charr[i] == '5' )
			    		{ if(charr[i-1] =='5') 
			    			{}
			    		 else	
			    		  st+="5";  }
			    	  
			    if (charr[i] == '6' )
			    		{ if(charr[i-1] =='6') 
			    			{}
			    		 else	
			    		  st+="6";  }
				    	
			    	
			    	
			} // ends else if i == 1
		
		 

		}//end for
		
//	System.out.println("str: " + str + " st: " + st);
				
		return(st);
	
	} // ends getDistinct	

	
	int getDistinctCharsCount (String input) {
	    boolean[] isItThere = new boolean[Character.MAX_VALUE];
    for (int i = 0; i < input.length(); i++) {
        isItThere[input.charAt(i)] = true;
    }

    int count = 0;
    for (int i = 0; i < isItThere.length; i++) {
        if (isItThere[i] == true){
            count++;
        }
    }

   // System.out.println("count: " + count);
    return count;
	} // ends getDistinctCharsCount
	
	
		double[][] sortNumbersWordsDouble (Object[] uwords, Object[] lwords, double [][] list){
	
		double lowest=90;
		int index = 0;
		
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<=15; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){
				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 90)
		   System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
		   
		   list[i][index]=0;
			 index= 0;
		     lowest=90;
            } //ends threshold
		  
		}// ends i
		
		System.out.println("======================================");
		
		return (list);
    }// ends sortnumwords
	
	
	
	//sort of numbers and move with their associated words - ascending
	int[][] sortNumbersWords (Object[] uwords, Object[] lwords, int [][] list){
	
		int lowest=90;
		int index = 0;
		
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<=15; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){
				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 90)
		   System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
		   
		   list[i][index]=0;
			 index= 0;
		     lowest=90;
            } //ends threshold
		  
		}// ends i
		
		System.out.println("======================================");
		
		return (list);
    }// ends sortnumwords
	
	int[][] sortNumbersWordsHighest (Object[] uwords, Object[] lwords, int [][] list){
	
		int highest=0;
		int index = 0;
		
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<=20; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){
				if(list[i][j] != 0 && list[i][j] > highest){
						highest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
		   System.out.println(" misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ highest index: " + highest );
		   
		   list[i][index]=0;
			 index= 0;
		     highest=0;
            } //ends threshold
		  
		}// ends i
		
		return (list);
    }// ends sortnumwords	
    
	
	String[] sortNumbersWordsWithReturn (Object[] uwords, Object[] lwords, int [][] list, int count){
	
		int lowest=100;
		int index = 0;
		String [] suggestion = new String [count];
		//System.out.println(" list length: " + list[0].length);
		//System.out.println("===============re======");
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 100 ){
		  // System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=100;
		     
		     
            } //ends threshold
		  
		}// ends i
		
	//	System.out.println("======================================");
		//System.out.println("sugges length: " + suggestion.length);
		
		return (suggestion);
    }// ends sortnumwords	

    
    	String[] sortNumbersWordsWithReturnDouble (Object[] uwords, Object[] lwords, double [][] list, int count){
	    // this method accepts list[][] with only one row; and lexi.length words
	    //
    		
		double lowest=100;
		int index = 0;
		String [] suggestion = new String [count];
		//System.out.println(" list length: " + list[0].length);
		//System.out.println("===============re======");
		for(int i=0; i<list.length; ++i){  //this will loop only once as list is with only one row; multiple columns
		  	 
		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 100 ){
		  // System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=100;
		     
		     
            } //ends threshold
		  
		}// ends i
		
	//	System.out.println("======================================");
		//System.out.println("sugges length: " + suggestion.length);
		
		return (suggestion);
    }// ends sortnumwords	
    
    
      	String[] sortNumbersWordsWithReturnDoubleLargest (Object[] uwords, Object[] lwords, double [][] list, int count){
	
		double lowest=-1;
		int index = 0;
		String [] suggestion = new String [count];
		//System.out.println(" list length: " + list[0].length);
		//System.out.println("===============re======");
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] > lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != -1 ){
		  // System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=-1;
		     
		     
            } //ends threshold
		  
		}// ends i
		
	//	System.out.println("======================================");
		//System.out.println("sugges length: " + suggestion.length);
		
		return (suggestion);
    }// ends sortnumwords	  
    
    
       	String[] sortNumbersWordsWithReturnDoubleLargestModified (Object[] uwords, Object[] lwords, double [][] list, int count){
	
		double lowest=-1;
		int index = 0;
		String [] suggestion = new String [count];
		//System.out.println(" list length: " + list[0].length);
		//System.out.println("===============re======");
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] > lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != -1 ){
		  // System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+",1.0";
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=-1;
		     
		     
            } //ends threshold
		  
		}// ends i
		
	//	System.out.println("======================================");
		//System.out.println("sugges length: " + suggestion.length);
		
		return (suggestion);
    }// ends sortnumwords	  
       
    
    
    
    public static String soundex(String s) { 
        char[] x = s.toUpperCase().toCharArray();
        char firstLetter = x[0];

        // convert letters to numeric code
        for (int i = 0; i < x.length; i++) {
            switch (x[i]) {

                case 'B':
                case 'F':
                case 'P':
                case 'V':
                    x[i] = '1';
                    break;

                case 'C':
                case 'G':
                case 'J':
                case 'K':
                case 'Q':
                case 'S':
                case 'X':
                case 'Z':
                    x[i] = '2';
                    break;

                case 'D':
                case 'T':
                    x[i] = '3';
                    break;

                case 'L':
                    x[i] = '4';
                    break;

                case 'M':
                case 'N':
                    x[i] = '5';
                    break;

                case 'R':
                    x[i] = '6';
                    break;

                default:
                    x[i] = '0';
                    break;
            }
        }

        // remove duplicates
        String output = "" + firstLetter;
        for (int i = 1; i < x.length; i++)
            if (x[i] != x[i-1] && x[i] != '0')
                output += x[i];

        // pad with 0's or truncate
        output = output + "0000";
        return output.substring(0, 4);
    }	
	String getSoundexCode1 (String str){
		
		char[] charr = str.toCharArray();
		
		String st = "";
		for(int i=0; i<charr.length; ++i){
		
			if(i == 0)
			{st = ""+charr[i];
			  
			}
	
			else {
				
			    if(charr[i] == 'a' || charr[i] == 'e' || charr[i] == 'i' || charr[i] == 'o' || charr[i] == 'u' || charr[i] == 'y' || charr[i] == 'h' || charr[i] == 'w')	
				 {	 
			     }
			 
			    else if (charr[i] == 'b' || charr[i] == 'p' || charr[i] == 'f' || charr[i] == 'v')
			    		{ if(charr[i-1] =='b' || charr[i-1] == 'p' || charr[i-1] == 'f' || charr[i-1] == 'v') 
			    			{}
			    		 else	
			    		  st+="1";  }
			    
			    else if (charr[i] == 'c' || charr[i] == 'g' || charr[i] == 'j' || charr[i] == 'k' || charr[i] == 'q' || charr[i] == 's' || charr[i] == 'x' || charr[i] == 'z')
			    		{ 
			    		 if(charr[i-1] == 'c' || charr[i-1] == 'g' || charr[i-1] == 'j' || charr[i-1] == 'k' || charr[i-1] == 'q' || charr[i-1] == 's' || charr[i-1] == 'x' || charr[i-1] == 'z')
			    		   {}
			    	   else
			    		st+="2";  }
				
				else if (charr[i] == 'd' || charr[i] == 't')
			    		{
			    		if(charr[i-1] == 'd' || charr[i-1] == 't')
			    			{}
			    		else
			    		st+="3";  }
				
				else if (charr[i] == 'l')
			    		{
			    			if(charr[i-1] == 'l')
			    				{}
			    			else
			    		       st+="4";  }
				
				else if (charr[i] == 'm' || charr[i] == 'n')
			    		{ 
			    		if(charr[i-1] == 'm' || charr[i-1] == 'n')
			    			{}
			    		else
			    		st+="5";  }
				
				else if (charr[i] == 'r')
			    		{
			    			if (charr[i-1] == 'r')
			    				{}
			    			else
  			    		    st+="6";  }
			    	
			    	
			    	
			} // ends else if i == 1
		
		 

		}//end for
		
//	System.out.println("str: " + str + " st: " + st);
		
		st = getDistinct2(st);
		
		return(st);
		
	}
    
	
	String getSoundexCode2 (String str){
		
		char[] charr = str.toCharArray();
		
		String st = "";
		for(int i=0; i<charr.length; ++i){
		
			if(i == 0)
			{st = ""+charr[i];
			  
			}
	
			else {
				
			    if(charr[i] == 'a' || charr[i] == 'e' || charr[i] == 'i' || charr[i] == 'o' || charr[i] == 'u' || charr[i] == 'y' || charr[i] == 'h' || charr[i] == 'w')	
				 {	 
			     }
			 
			    else if (charr[i] == 'b' || charr[i] == 'p' || charr[i] == 'f' || charr[i] == 'v')
			    		  st+="1";
			    
			    else if (charr[i] == 'c' || charr[i] == 'g' || charr[i] == 'j' || charr[i] == 'k' || charr[i] == 'q' || charr[i] == 's' || charr[i] == 'x' || charr[i] == 'z')
			    		st+="2";  
				
				else if (charr[i] == 'd' || charr[i] == 't')

			    		st+="3"; 
				
				else if (charr[i] == 'l')
		
			    		       st+="4"; 
				
				else if (charr[i] == 'm' || charr[i] == 'n')
	
			    		st+="5"; 
				
				else if (charr[i] == 'r')

  			    		    st+="6";
			    	
			    	
			    	
			} // ends else if i == 1
		
		 

		}//end for
		
//	System.out.println("str: " + str + " st: " + st);
		
		st = getDistinct(st);
		
		return(st);
		
	}

	int getRankNo (String uword, String lword){
 	 
 	  
			    int rank=0;
	
			    if(uword.equals(lword))
			    	rank=1;
			    
		return (rank);
	
	} // ends getRankNo
	
	
	
 int getRankNo2 (String uword, String lword){
 	 
 	  
 	 			int count = 0;
			    int rank=0;
			    int mi=0;
			    	char[] uwarr = uword.toCharArray();			
			    	char[] lwarr = lword.toCharArray();
               // System.out.println("lstr: " + lstr);
			 
			    		
			    		for (int x=0; x<uwarr.length; ++x)
			    		for(int y=0; y<lwarr.length; ++y)
			    		   if(uwarr[x] == lwarr[y])
			    		     { ++count;  break;}
			    
            mi = Math.abs(uwarr.length + lwarr.length - count);
            
            if(Math.abs(uwarr.length - lwarr.length) <=3){
            

			 if(Math.abs(mi - uwarr.length) == 0 && Math.abs(mi - lwarr.length) == 0)
				rank = 1;
			
			else if((Math.abs(mi - uwarr.length) == 0 && Math.abs(mi - lwarr.length) == 1) || (Math.abs(mi - uwarr.length) == 1 && Math.abs(mi - lwarr.length) == 0)  )
				rank = 2;
				 
			else if(Math.abs(mi - uwarr.length) == 1 && Math.abs(mi - lwarr.length) == 1)
				rank = 3;
			

		//	System.out.println (" misspell code: " + uword + " lcode " + lword + " Rank: " + rank);
		  
			}
		return (rank);
	
	} // ends getRankNo
	

	String[] sortNumbersWordsWithReturn2 (Object[] uwords, String[] lwords, int [][] list, int count){
	
		int lowest=100;
		int index = 0;
		String [] suggestion = new String [count];
		//System.out.println(" list length: " + list[0].length);
		
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){
				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 100 ){
		  // System.out.println("=======================");		
		  // System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ return2 index: " + lowest );
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi;//+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index= 0;
		     lowest=100;
		     
		     
            } //ends threshold
		  
		}// ends i
		
	//	System.out.println("======================================");
		//System.out.println("sugges length: " + suggestion.length);
		
		return (suggestion);
    }// ends sortnumwords	

///////////////////////////////////// Get Rank with similarity code
    int	getRankUnigramMI (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
 	
				rank = Math.abs(dustr.length() + dlstr.length() -2)*mi;	 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRank method    
    
   
       int	getRankBigramMI (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
 	
				rank = Math.abs(ustr.length() + lstr.length() -2)*mi;	 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRank method    
    
///////////////////////////////////// Edit Distance 0
    int	getRankUnigram0 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    			rank = Math.abs(dustr.length() + dlstr.length() -2 * mi);
    	
 	              /*
    				 if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

					 
				 	 else
					 	 {rank = 100;}
					 
					*/ 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigram0 method

    int  getRankBigram0 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
		    			//rank = Math.abs(ustr.length() + lstr.length() -2 * mi);
		    		  rank = mi;
		    		    			//rank = Math.abs(ustr.length() + lstr.length() -2 * mi);

				/*
				 	 if((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 else
				 	  	  {rank = 100;}
					*/ 
       return(rank);
   }//ends method getRankBigram0
   
  
   /////////////////////// Edit Distance 1
   
       int	getRankUnigram1 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    	              
    				if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

					 
				 	 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigram1 method

    int  getRankBigram1 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
				
				 	 if((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 8;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==8 && Math.abs(lstr.length()-1 - mi) ==7)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==7 && Math.abs(lstr.length()-1 - mi) ==8)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else
				 	  	  {rank = 100;}
					 
       return(rank);
   }//ends method getRankBigram1
   

   /////////////////////// Edit Distance 2
   
       int	getRankUnigram2 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    	              
    				if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==3){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }				 	 
				 	 
					 
				 	 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigrm2 method

    int  getRankBigram2 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
				
				 	 if((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==3)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==3 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 8;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==8 && Math.abs(lstr.length()-1 - mi) ==7)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==7 && Math.abs(lstr.length()-1 - mi) ==8)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else
				 	  	  {rank = 100;}
					 
       return(rank);
   }//ends method getRankBigram2
      
   
       int	getRankUnigram3 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    	              
    				if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 

				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==3) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }				 	 
				 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==3){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }				 	 
				 	 
					 
				 	 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigrm3 method

    int  getRankBigram3 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
				
				 	 if((Math.abs(ustr.length()-1 - mi) ==0 && Math.abs(lstr.length()-1 - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if(((Math.abs(ustr.length()-1 - mi) ==0 && Math.abs(lstr.length()-1 - mi) ==3) )|| ((Math.abs(ustr.length()-1 - mi) ==3 && Math.abs(lstr.length()-1 - mi) ==0))){
				 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==3)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==3 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==4)){
					 	     rank = 8;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==4 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==5)){
					 	     rank = 11;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==5 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 12;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 				 	 
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 13;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 14;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 15;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==8 && Math.abs(lstr.length()-1 - mi) ==7)){
					 	     rank = 16;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==7 && Math.abs(lstr.length()-1 - mi) ==8)){
					 	     rank = 16;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else
				 	  	  {rank = 100;}
					 
       return(rank);
   }//ends method getRankBigram3
   

       int	getRankUnigram4 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    	              
    				if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==3){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }				 	 
				 	 
					 
				 	 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigrm4 method

    int  getRankBigram4 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
				
				 	 if((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==3)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==3 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==4) )|| ((Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 8;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
				 	 
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==8 && Math.abs(lstr.length()-1 - mi) ==7)){
					 	     rank = 11;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==7 && Math.abs(lstr.length()-1 - mi) ==8)){
					 	     rank = 12;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else
				 	  	  {rank = 100;}
					 
       return(rank);
   }//ends method getRankBigram4   
   
   
 
        int	getRankUnigram5 (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    	              
    				if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==3){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==4) {
				 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==4 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

					 
				 	 
				 	 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 
	
    
	
   }//ends getRankUnigrm5 method

    int  getRankBigram5 (String dustr, String dlstr, String ustr, String lstr, int mi){
   
  
		int rank=0;
				
				 	 if((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==0)){
				 	    rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }

				 	 else if(((Math.abs(ustr.length() - mi) ==0 && Math.abs(lstr.length() - mi) ==1) )|| ((Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==0))){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==1 && Math.abs(lstr.length() - mi) ==1)){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==2)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==2 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==1 && Math.abs(lstr.length()-1 - mi) ==3)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==3 && Math.abs(lstr.length()-1 - mi) ==1)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==2 && Math.abs(lstr.length() - mi) ==2)){
					 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==3 && Math.abs(lstr.length() - mi) ==3)){
					 	     rank = 7;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length() - mi) ==4 && Math.abs(lstr.length() - mi) ==4)){
					 	     rank = 8;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }
				 	 
				 	 else if ( (Math.abs(ustr.length() - mi) ==5 && Math.abs(lstr.length() - mi) ==5)){
					 	     rank = 9;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==8 && Math.abs(lstr.length()-1 - mi) ==7)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 else if ( (Math.abs(ustr.length()-1 - mi) ==7 && Math.abs(lstr.length()-1 - mi) ==8)){
					 	     rank = 10;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else
				 	  	  {rank = 100;}
					 
       return(rank);
   }//ends method getRankBigram5  
   
   
      int	getRankUnigram (String dustr, String dlstr, String ustr, String lstr, int mi){
		
    	int rank=0;
    	
    				 if((Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==0)){
				 	          rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0");
				 	 }	 	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==1) {
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-1");
				 	 }
	 
				 	 
				 	 
				 	 else if (Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==1){
					 	     rank = 3;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1");
				 	 }

				 	 
				 	 
				 	 else if(Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==2){
				 	     rank = 2;
				 	     //System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-2");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 2;
				 	     //System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 0-2");
				 	 }
				 	 
				 	 
				 	 else if(Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==3) {
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }
				 	 
				
				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 2;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }


				 	 else if(Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==4) {
				 	     rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }
				 	 
				
				 	 else if (Math.abs(dustr.length() - mi) ==4 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }
				 	 
				 	 else if(Math.abs(dustr.length() - mi) ==0 && Math.abs(dlstr.length() - mi) ==5) {
				 	     rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }
				 	 
				
				 	 else if (Math.abs(dustr.length() - mi) ==5 && Math.abs(dlstr.length() - mi) ==0){
				 	     rank = 1;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }				 	 
	
				 	 
				 	 else if(Math.abs(dustr.length() - mi) ==1 && Math.abs(dlstr.length() - mi) ==2) {
				 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==1){
				 	     rank = 4;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }
				 	 	 
				 	 
				 	 else if ((Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==2)){
					 	     rank = 5;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 2");
				 	 }

				 	 
				 	 
				 	 else if((Math.abs(dustr.length() - mi) ==2 && Math.abs(dlstr.length() - mi) ==3)){
				 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }

				 	 else if (Math.abs(dustr.length() - mi) ==3 && Math.abs(dlstr.length() - mi) ==2){
				 	     rank = 6;
				 	    // System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at -MI: 1-2");
				 	 }				 	 
				 	 
		 	 

				 	 
				 	 else if (( Math.abs(dustr.length() - mi) == 3 && Math.abs(dlstr.length() - mi) ==3 ) ){
					rank=7;
					// System.out.println(" Misspell: " + ustr + " Suggestion: " + lstr + " at MI: 3+3+ ");
					 }
    

					 else
					 	 {rank = 100;}
					 
					 
					 
			return (rank);		 

   }//ends getRankUnigrm method
  
   
 int editDistance (String word1, String word2)
{
	int len1 = word1.length();
	int len2 = word2.length();
 
	// len1+1, len2+1, because finally return dp[len1][len2]
	int[][] dp = new int[len1 + 1][len2 + 1];
 
	for (int i = 0; i <= len1; i++) {
		dp[i][0] = i;
	}
 
	for (int j = 0; j <= len2; j++) {
		dp[0][j] = j;
	}
 
	//iterate though, and check last char
	for (int i = 0; i < len1; i++) {
		char c1 = word1.charAt(i);
		for (int j = 0; j < len2; j++) {
			char c2 = word2.charAt(j);
 
			//if last two chars equal
			if (c1 == c2) {
				//update dp value for +1 length
				dp[i + 1][j + 1] = dp[i][j];
			} else {
				int replace = dp[i][j] + 1;
				int insert = dp[i][j + 1] + 1;
				int delete = dp[i + 1][j] + 1;
 
				int min = replace > insert ? insert : replace;
				min = delete > min ? min : delete;
				dp[i + 1][j + 1] = min;
			}
		}
	}
 
	return dp[len1][len2];
}  
   
   
}//ends 