GNU GPL License

CLIQUE source code
Author: Leena Al-Hussaini
October 2020

This source code is for research purposes.
 
To run CLIQUE software, you must have Java installed on your machine: 

0) Download clique.zip from 
   https://multi-error-misspellings.github.io
1) Unzip clique.zip
2) Navigate to clique folder
3) Compile java files, by typing on command-line prompt:
   > javac *.java
4) Run the program, by typing on command-line prompt:
   > java clique
5) Enter your word to check for misspellings. 
   Enter one isolated word with no spaces of special characters.

(c) CLIQUE spell checker for multi-error misspellings, 2020