/*
            GNU GPL License

Copyright (C) 2020 Leena Al-Hussaini

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

See the GNU General Public License for more details.
*/

/* Please do not remove this license notice when using the program */


import java.io.*;
import java.lang.*;
import java.util.*;


class AuxiliaryMethods{
	
	AuxiliaryMethods(){}

//------------
//This method exists in RunHamming.java, RunJaro.java,
// RunLCS.java, RunNG.java
//------------
double[][] sortNumbersWordsDouble (Object[] uwords, Object[] lwords, double [][] list){
	
		double lowest=90;
		int index = 0;
		
		for(int i=0; i<list.length; ++i){
		  	 
		     
		  for(int a=0; a<=15; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){
				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 90)
		   System.out.println( a + " misspell: " + (String) uwords[i] + " Sugg: " + (String) lwords[index] + " @ lowest index: " + lowest );
		   
		   list[i][index]=0;
			 index= 0;
		     lowest=90;
            } //ends threshold
		  
		}// ends i
		
		System.out.println("======================================");
		
		return (list);
    }// ends sortNumbersWordsDouble


//------------
//This method exists in RunHamming.java, RunJaro.java, RunLCS.java
//------------
String[] sortNumbersWordsWithReturnDouble (Object[] uwords, Object[] lwords, double [][] list, int count){

    		
		double lowest=100;
		int index = 0;
		String [] suggestion = new String [count];

//this will loop only once as list is with only one row; multiple columns
		for(int i=0; i<list.length; ++i){
		  	 		     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] < lowest){
						lowest = list[i][j];
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != 100 ){
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=100;
		     
		     
            } //ends threshold
		  
		}// ends i
		
		return (suggestion);
    }// ends sortNumbersWordsWithReturnDouble	
    
    
//------------
// This method is used in RunNG.java
//------------
String[] sortNumbersWordsWithReturnDoubleLargest (Object[] uwords, Object[] lwords, double [][] list, int count){
	
		double lowest=-1;
		int index = 0;
		String [] suggestion = new String [count];

		for(int i=0; i<list.length; ++i){
		  			     
		  for(int a=0; a<count; ++a){ // 14 is the threshold 
            
			for(int j=0; j<list[0].length; ++j){

				if(list[i][j] != 0 && list[i][j] > lowest){
						lowest = list[i][j];
						//System.out.println("lowest: " + lowest);
						index = j;
					
				}//ends if
			}//ends j
			
			if(lowest != -1 ){
	       String lexi = (String) lwords[index];
	       String no = (String) ","+lowest;
		   
		   String str = lexi+no;
		    suggestion[a]=  str;
		    }
		   list[i][index]=0;
			 index=0;
		     lowest=-1;
		     
		     
            } //ends threshold
		  
		}// ends i
				
		return (suggestion);
    }// ends sortNumbersWordsWithReturnDoubleLargest	  


}//ends class AuxiliaryMethods