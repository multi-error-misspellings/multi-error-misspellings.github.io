
// The lexicon loading phase is to launch the lexicon (dictionary) into
// memory preprocessing to user files
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.concurrent.*;


class CheckMisspell {
	
        
        String[] lwords;
        String[] userwords;
        
        public CheckMisspell(Object[] uwords, Object[] lexicon) {
        	lwords = new String[lexicon.length];
        	userwords = new String[uwords.length];
        	
        	
        	//System.out.println("check misspell constructor");
        	//System.out.println("lwords.length: " + lwords.length + "uwords.length: " + uwords.length);

        	
        	for(int i=0; i<lexicon.length; ++i)
        	 lwords[i] = (String)lexicon[i];
        	for(int i=0; i<uwords.length; ++i)
        	 userwords[i] = (String)uwords[i];
        	
        } //ends method
        
	public Object[] CheckForMisspelling () throws Exception{
		ArrayList misspell = new ArrayList();
		String str;
		int flag;
		Object m[]= {""};
		
		for(int i=0; i<userwords.length; ++i){
		        //get first user word to check for misspelling
			str = userwords[i];	
			flag=0;
			//System.out.println("str uword: " + str);
			for(int j=0; j<lwords.length; ++j){
				
				if(str.equals(lwords[j])){
					//System.out.println("This word: "+str+" is correctly spelled");
					flag=1;
					break;
				}
				
				
			}//ends for j
			
		if(flag == 0){
		misspell.add(str);}
		else 
		{
			System.out.println("not misspell: " + str);
			String temp = (String)(str+str);
			misspell.add(temp);
			 m = misspell.toArray(); 	
         return (m);
		
		}
	//	System.out.println("Misspelling: " + str);
		
			
		}//ends for i
		
	
		//System.out.println(" Misspell arraylist: "+ misspell);
		
         m = misspell.toArray(); 	
         return (m);
        }//ends call simulator
		
}

