
/*
            GNU GPL License

Copyright (C) 2020 Leena Al-Hussaini

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

See the GNU General Public License for more details.
*/

/* Please do not remove this license notice when using the program */



// The lexicon loading phase is to launch the lexicon
// (dictionary) into memory preprocessing user files
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.concurrent.*;


class CheckMisspell {
	
        
        String[] lwords;
        String[] userwords;
        
        public CheckMisspell(Object[] uwords, Object[] lexicon) {
        	lwords = new String[lexicon.length];
        	userwords = new String[uwords.length];

        	
        	for(int i=0; i<lexicon.length; ++i)
        	 lwords[i] = (String)lexicon[i];
        	for(int i=0; i<uwords.length; ++i)
        	 userwords[i] = (String)uwords[i];
        	
        } //ends method
        
	public Object[] CheckForMisspelling () throws Exception{
		ArrayList misspell = new ArrayList();
		String str;
		int flag;
		Object m[]= {""};
		
		for(int i=0; i<userwords.length; ++i){
		        //get first user word to check for misspelling
			str = userwords[i];	
			flag=0;

			for(int j=0; j<lwords.length; ++j){
				
				if(str.equals(lwords[j])){
					flag=1;
					break;
				}
				
				
			}//ends for j
			
		if(flag == 0){
		misspell.add(str);}
		else 
		{
			System.out.println("not misspell: " + str);
			String temp = (String)(str+str);
			misspell.add(temp);
			 m = misspell.toArray(); 	
         return (m);
		
		}
			
		}//ends for i
				
         m = misspell.toArray(); 	
         return (m);
        }//ends call simulator		
}

