/*
            GNU GPL License

Copyright (C) 2020 Leena Al-Hussaini

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

See the GNU General Public License for more details.
*/

/* Please do not remove this license notice when using the program */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class clique {
	
	public static void main (String args[]) {
	
		
		System.out.println ();
		System.out.println ();		
		System.out.println ("*** CLIQUE, MULTI-ERROR MISSPELLINGS, SPELL CHECKER ***");
		System.out.println ();
		System.out.println ();
	
	try{


	// Read line from console.
	String line;

	
	String ms="";

				while(!ms.equals("0")){
					
		System.out.println ();
		System.out.println ();
		System.out.println ("Enter your misspelling - one word of English, like: space, no special characters  - enter 0 to exit: ");

	// Get BufferedReader for System.in.

		BufferedReader in = new BufferedReader(
	    new InputStreamReader(System.in));

		
					for(int i=0; i < 5; ++i){
					
						in = new BufferedReader(new InputStreamReader(System.in));

						// Read line from console.
						ms = in.readLine();
		
						if (ms.equals("")) {
						System.out.println ();
						System.out.println ("Enter your misspelling - empty string is not a misspell: ");
							
						} 
						else if (ms.equals("0"))
							{ System.exit(0);}
	  	 
						else
						{
							System.out.println();
							System.out.println (" Your misspell is: " + ms);
							System.out.println();
							System.out.println (" Suggestions: ");
							break;
						}
	  	 
					}//ends for loop 5
	  
			
					
					
	         //run Jaro Winkler algorithm
			 RunJaro rj = new RunJaro ();
			 int code = rj.distance(ms);
				
			 if(code == 1) // i.e. misspell is a misspell
			 {// if user did not find the result
			 //run 2gram algorithm
			 System.out.println();
			 System.out.println (" Did you find the correct word in the suggestion list?");
			 System.out.println (" Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm

			 	 RunNG rn = new RunNG();
			 	 rn.distance(ms);
			 	 
			 	 System.out.println();
				 System.out.println (" Did you find the correct word in the suggestion list?");
			     System.out.println (" Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm
			 	 
			 	 RunLCS rl = new RunLCS();
			 	 rl.distance(ms);
			 	 
				System.out.println();
				 System.out.println (" Did you find the correct word in the suggestion list?");
			     System.out.println (" Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm
			 	 
				RunHamming rh = new RunHamming();
			 	rh.distance(ms);

			 	 System.out.println();
			 	 System.out.println(" If you did not find the correct word for your ");
			 	 System.out.println(" misspelling, then CLIQUE can not find it as CLIQUE ");
			 	 System.out.println(" executed all algorithms serving your misspelling.");


			 }		 	 
			 	 
			 	else 
			 	 System.exit(0);	 
			 	 

			 }
			else 
			 	 System.exit(0);				
			 	}
				
				} // if code==1

			} //!ms.equals("0")

	}catch(Exception e){}
	
	
	}//ends main
}//end class