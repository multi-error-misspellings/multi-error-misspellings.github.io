/*
            GNU GPL License

Copyright (C) 2020 Leena Al-Hussaini

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

See the GNU General Public License for more details.
*/

/* Please do not remove this license notice when using the program */

import info.debatty.java.stringsimilarity.*;


import java.io.*;
import java.util.*;
import java.util.StringTokenizer;

class RunHamming {
	
	public RunHamming(){}
	
	public int distance (String ms) {
		
		// variables
		Object[] lexiwords={""};
		Object[] suserwords = {""};
		Object[] misspell = {""};


		String arg1 = ms;
		String userfileword = "";
		
		userfileword = (String) arg1;
		
		
		//Step 1: Loading lexicon into memory			
			
			LexiconLoading ld = new LexiconLoading(userfileword);
			try{
			      lexiwords = ld.readFile();
				}catch(Exception ex) {}
		
        
			try{
			//reads lexicon and user words to check for misspelling
			suserwords[0] = (Object) userfileword;
			CheckMisspell cm = new CheckMisspell(suserwords,lexiwords);
			
			misspell = cm.CheckForMisspelling();
			
			}catch(Exception emiss){}
			
			String temp = (String)(userfileword+userfileword);

			 if(misspell[0].equals(temp))
			 	 {System.out.println("Your entered misspell is not a misspell; i.e. it exists in the dictionary");
			 	  return(-1);
			 	 }
			else {   			
			
		
			// Damerau test
		      double[][] damerauRecords = new double[1][lexiwords.length];
		      for(int q=0; q<lexiwords.length; ++q){
		      
		      	  String m = (String) misspell[0];
		      	  String l = (String) lexiwords[q];
   	  		      Hamming da = new Hamming(l,m);
		      	  double r = da.getHammingDistance();
		      	  if (r != -1)
		      	  damerauRecords[0][q]= r;
		      }
		      	  
			AuxiliaryMethods am = new AuxiliaryMethods();
            String[] sugg = am.sortNumbersWordsWithReturnDouble (misspell, lexiwords, damerauRecords,10);
			
            for(int p=0; p<10; ++p){
              int i=0;
              String in = (String) sugg[p];
            	StringTokenizer st = new StringTokenizer (in, ",");
            	
            	while (st.hasMoreElements()) {
            		if(i== 0)
            	      System.out.println( st.nextElement());
            	    else if(i == 1)
            	    	st.nextElement();
            	    ++i;
            	}
			}
					
			return(1);
			 }//ends else misspell exists
			
	}//ends main	
	
}//ends class
