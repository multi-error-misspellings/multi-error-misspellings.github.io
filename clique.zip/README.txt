CLIQUE source code
January 2018

This source code is for research purposes of the author.
Author name is kept anonymous for anonymized ACL paper submission.

To run CLIQUE software, type on command-line prompt:
> java clique

(c) multi-error-misspellings project, 2018