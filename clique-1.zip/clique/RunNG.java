import info.debatty.java.stringsimilarity.*;


import java.io.*;
import java.util.*;

class RunNG {
	
	public RunNG(){}
	
	public void distance (String ms) {
		
		// variables
		Object[] lexiwords={""};
		Object[] userwords={""};
		Object[] grouped = {""};
		Object[] suserwords = {""};
		Object[] misspell = {""};
		int[][] lexinodes = new int[0][0];
		int[][] lexiedges = new int[0][0];
		int[][] usernodes = new int[0][0];
		int[][] useredges = new int[0][0];
		int[][] coNodes = new int[0][0];
		int[][] coEdges = new int[0][0];
		double[] independentPro = new double[0];
		double[][] conditionalPro = new double[0][0];
		double[][] jointPro = new double[0][0];
		double[][] pmi = new double[0][0];
		String[] belief = new String[0];
		double[][] cTree = new double[0][0];
		Object[] entropy = new Object[0];
		double[] dictentropy = new double[0];
		Object[][] jentropy = new Object[0][0];
		Object[][] dTree = new Object[0][0];
		int [][] bigram = new int [0][0];
		int [][] unigram = new int [0][0];
		int [][] record = new int [0][0];
		int [][] miunigram = new int [0][0];
		int [][] mibigram = new int [0][0];
		String [] bigrecord = new String [0];
		String [] bigrecord2 = new String [0];
		
		
		
		String arg1 = ms;
		//String usermisspell = args[1];
//		String filename = args[1];
		String userfileword = "";
	/*			     String fileoutput = args[2];
        	//Writer writer = null;	
            PrintWriter writer = null;   
        	
         
        		//writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileoutput), "utf-8"));
        	try{
        		writer = new PrintWriter(fileoutput, "UTF-8");
		}catch(Exception e) {}
		
		if(args[0].equals("-f")) {
			/*
		    System.out.println("-----------------------");
			System.out.println("--- User File Load ----");
			System.out.println("-----------------------");
             */	        
	/*		try{
             	        UserFileLoading uf = new UserFileLoading(filename);
			
             	        
			      userwords = uf.readFile();
			      
			  
			   //for(int j=0; j<userwords.length; ++j)       
			    // System.out.println("printing userwords contents from client: "+userwords[j]);
             	        }catch(Exception eu){}
		*/
		
      //     for(int i=0; i<userwords.length; ++i){
           	   
           	   userfileword = (String) arg1;
		
		
		//Step 1: Loading lexicon into memory			
			/*
			System.out.println("---------------------------------------");
			System.out.println("--- Loading Phase----------------------");
			System.out.println("---------------------------------------");
			*/
			
			
			/*
			System.out.println("-----------------------");
			System.out.println("---Lexicon Loading ----");
			System.out.println("-----------------------");
			*/
			
			LexiconLoading ld = new LexiconLoading(userfileword);
			try{
			      lexiwords = ld.readFile();
			  
			 //  for(int j=0; j<lexiwords.length; ++j)       
			   //  System.out.println("printing lexiwords contents from client: "+lexiwords[j]);
				}catch(Exception ex) {}
		

            /* 
 			System.out.println("-----------------------");
			System.out.println("--- Check Misspell ----");
			System.out.println("-----------------------");
             */	        
			try{
			//reads lexicon and user words to check for misspelling
			suserwords[0] = (Object) userfileword;
			CheckMisspell cm = new CheckMisspell(suserwords,lexiwords);
			
			misspell = cm.CheckForMisspelling();
             	          //for(int j=0; j<misspell.length; ++j)       
			    // System.out.println("printing misspell contents: "+misspell[j]);
			
			}catch(Exception emiss){}
			
			// Damerau test
  		      NGram da = new NGram();
			double[][] damerauRecords = new double[1][lexiwords.length];
		      for(int q=0; q<lexiwords.length; ++q){
		      
		      	  String m = (String) misspell[0];
		      	  String l = (String) lexiwords[q];
		      	  double r = da.distance(l,m);
		    
		      	  damerauRecords[0][q]= r;
		      }
		      	  
			AuxiliaryMethods am = new AuxiliaryMethods();
			
			//double[][] dlist = am.sortNumbersWordsDouble(misspell, lexiwords, damerauRecords);
            String[] sugg = am.sortNumbersWordsWithReturnDoubleLargest (misspell, lexiwords, damerauRecords,10);
			
              for(int p=0; p<10; ++p){
              int i=0;
              String in = (String) sugg[p];
            	StringTokenizer st = new StringTokenizer (in, ",");
            	
            	while (st.hasMoreElements()) {
            		if(i== 0)
            	      System.out.println( st.nextElement());
            	    else if(i == 1)
            	    	st.nextElement();
            	    ++i;
            	}
			}
			
					

			
	
			
		/*						    //dump output to a file for latter processing	
		    String wmstr = (String) misspell[0];		    
			  writer.write(wmstr);
    			writer.println();

        		for(int x=0; x<sugg.length; ++x){
             	   String st = (String) sugg[x];
             	  // System.out.println(st);
             	  if(st!=null)
        			writer.write(st);
        		  else
        		  	  writer.write("empty");
        		  
        			writer.println();
             	}
        		
			*/
	
						
			
		        

			
	//			 }// ends loop over userwords

		//	}//ends if -f
			
			    	//	try {writer.close();} catch (Exception ex) {/*ignore*/}
			
	}//ends main	
	
}//ends class
