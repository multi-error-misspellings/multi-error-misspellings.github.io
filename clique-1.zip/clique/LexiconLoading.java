
// The lexicon loading phase is to launch the lexicon (dictionary) into
// memory preprocessing to user files
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.concurrent.*;

  class LexiconLoading {
       
        String name;
        
        public LexiconLoading(String usermisspell) {
        	name = usermisspell;
        	
        } //ends method
        
	public Object[] readFile () throws Exception{
		
		    BufferedReader reader;
        	File inputFile;
        	FileInputStream fis;
        	int i=0; String str;
        	ArrayList a = new ArrayList();
		
				  
		    name = name.toLowerCase();
		    char [] umisspell = name.toCharArray();		    
		    
		   if(umisspell[0] == 'a')
		   	   name = "lexiconA.text";
		   else if(umisspell[0] == 'b')
		   	   name = "lexiconB.text";
		   else if(umisspell[0] == 'c')
		   	   name = "lexiconC.text";
		   else if(umisspell[0] == 'd')
		   	   name = "lexiconD.text";
		   else if(umisspell[0] == 'e')
		   	   name = "lexiconE.text";
		   else if(umisspell[0] == 'f')
		   	   name = "lexiconF.text";
		   else if(umisspell[0] == 'g')
		   	   name = "lexiconG.text";
		   else if(umisspell[0] == 'h')
		   	   name = "lexiconH.text";
		   else if(umisspell[0] == 'i')
		   	   name = "lexiconI.text";
		   else if(umisspell[0] == 'j')
		   	   name = "lexiconJ.text";
		   else if(umisspell[0] == 'k')
		   	   name = "lexiconK.text";
		   else if(umisspell[0] == 'l')
		   	   name = "lexiconL.text";
		   else if(umisspell[0] == 'm')
		   	   name = "lexiconM.text";
		   else if(umisspell[0] == 'n')
		   	   name = "lexiconN.text";
		   else if(umisspell[0] == 'o')
		   	   name = "lexiconO.text";
		   else if(umisspell[0] == 'p')
		   	   name = "lexiconP.text";
		   else if(umisspell[0] == 'q')
		   	   name = "lexiconQ.text";
		   else if(umisspell[0] == 'r')
		   	   name = "lexiconR.text";
		   else if(umisspell[0] == 's')
		   	   name = "lexiconS.text";
		   else if(umisspell[0] == 't')
		   	   name = "lexiconT.text";
		   else if(umisspell[0] == 'u')
		   	   name = "lexiconU.text";
		   else if(umisspell[0] == 'v')
		   	   name = "lexiconV.text";
		   else if(umisspell[0] == 'w')
		   	   name = "lexiconW.text";
		   else if(umisspell[0] == 'x')
		   	   name = "lexiconX.text";
		   else if(umisspell[0] == 'y')
		   	   name = "lexiconY.text";
		   else if(umisspell[0] == 'z')
		   	   name = "lexiconZ.text";
		
		
		
		
		
        	String file = "./lexicon/"+name;
 
        	
        	try{
        		//fin = new FileInputStream(file);
        		inputFile = new File(file);
        		reader = new BufferedReader (new InputStreamReader (new BufferedInputStream (new FileInputStream (inputFile))));

        	
        		while((str = reader.readLine()) != null ) {
       	                       // System.out.println(str);
       	                        //tokenizer string before insertion for cases like coca-cola
       	                        a.add(str.toLowerCase());
        		 }	
        		
        	}catch (FileNotFoundException e){
        		System.out.println("File Not Found " + name);
        	}catch (IOException e){
        		System.out.println (e);
        	}
        	
       //System.out.println("File found" + file); 
       
       //reading file one-by-one word
      
       //System.out.println ("Contents of a in "+file+ " is: "+ a);
       
       Object[] bb =  a.toArray();
       //aa = new Object[a.size()];
       /*
        for(int j=0; j<bb.length; ++j){
        	System.out.print (" " +(String) bb[j]);
        }
       
       System.out.println();   
        */	
         return (bb);
        }//ends call simulator
	

	
	
	// creating lexicon forest of 26 alphabetical rooted tree
	// This method output 1 on successful completion and 0 otherwise
	//int createLexiconForest ();
	
}

