
// The lexicon loading phase is to launch the lexicon (dictionary) into
// memory preprocessing to user files
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.concurrent.*;

  class Availability {
       
    public Availability() {}  

    //////////////////////////////////////// Lexicon loading

	public String getFileNameMisspell (String misspell) {
		    String name="";
			name = misspell;  
		    name = name.toLowerCase();
		    char [] umisspell = name.toCharArray();		    
		    
		   if(umisspell[0] == 'a')
		   	   name = "lexiconA.text";
		   else if(umisspell[0] == 'b')
		   	   name = "lexiconB.text";
		   else if(umisspell[0] == 'c')
		   	   name = "lexiconC.text";
		   else if(umisspell[0] == 'd')
		   	   name = "lexiconD.text";
		   else if(umisspell[0] == 'e')
		   	   name = "lexiconE.text";
		   else if(umisspell[0] == 'f')
		   	   name = "lexiconF.text";
		   else if(umisspell[0] == 'g')
		   	   name = "lexiconG.text";
		   else if(umisspell[0] == 'h')
		   	   name = "lexiconH.text";
		   else if(umisspell[0] == 'i')
		   	   name = "lexiconI.text";
		   else if(umisspell[0] == 'j')
		   	   name = "lexiconJ.text";
		   else if(umisspell[0] == 'k')
		   	   name = "lexiconK.text";
		   else if(umisspell[0] == 'l')
		   	   name = "lexiconL.text";
		   else if(umisspell[0] == 'm')
		   	   name = "lexiconM.text";
		   else if(umisspell[0] == 'n')
		   	   name = "lexiconN.text";
		   else if(umisspell[0] == 'o')
		   	   name = "lexiconO.text";
		   else if(umisspell[0] == 'p')
		   	   name = "lexiconP.text";
		   else if(umisspell[0] == 'q')
		   	   name = "lexiconQ.text";
		   else if(umisspell[0] == 'r')
		   	   name = "lexiconR.text";
		   else if(umisspell[0] == 's')
		   	   name = "lexiconS.text";
		   else if(umisspell[0] == 't')
		   	   name = "lexiconT.text";
		   else if(umisspell[0] == 'u')
		   	   name = "lexiconU.text";
		   else if(umisspell[0] == 'v')
		   	   name = "lexiconV.text";
		   else if(umisspell[0] == 'w')
		   	   name = "lexiconW.text";
		   else if(umisspell[0] == 'x')
		   	   name = "lexiconX.text";
		   else if(umisspell[0] == 'y')
		   	   name = "lexiconY.text";
		   else if(umisspell[0] == 'z')
		   	   name = "lexiconZ.text";
		
		   return name;
	
	}
    
    
    
    
    
    public  Object[] readFile (String fileName) throws Exception{

    	    String name = fileName;
		    BufferedReader reader;
        	File inputFile;
        	FileInputStream fis;
        	int i=0; String str;
        	ArrayList a = new ArrayList();
	
        	
		    String file = fileName;

        	
        	try{
        		//fin = new FileInputStream(file);
        		inputFile = new File(file);
        		reader = new BufferedReader (new InputStreamReader (new BufferedInputStream (new FileInputStream (inputFile))));

        	
        		while((str = reader.readLine()) != null ) {
       	                       // System.out.println(str);
       	                        //tokenizer string before insertion for cases like coca-cola
       	                        a.add(str.toLowerCase());
        		 }	
        		
        	}catch (FileNotFoundException e){
        		System.out.println("File Not Found " + name);
        	}catch (IOException e){
        		System.out.println (e);
        	}
        	
       //System.out.println("File found" + file); 
       
       //reading file one-by-one word
      
       //System.out.println ("Contents of a in "+file+ " is: "+ a);
       
       Object[] bb =  a.toArray();
       //aa = new Object[a.size()];
      
       
         return (bb);
        }//ends call simulator
	

        

public Object[] CheckForMisspelling (Object[] uwords, Object[] lexicon, String lexiFile) throws Exception{
	 String[] lwords;
     String[] userwords;

        //FileUtil util = new FileUtil();
        Availability avail = new Availability();

            String file = lexiFile;
            System.out.println("File: " + file);
        
     		lwords = new String[lexicon.length];
        	userwords = new String[uwords.length];
        	       	
        	for(int i=0; i<lexicon.length; ++i)
        	 lwords[i] = (String)lexicon[i];
        	for(int i=0; i<uwords.length; ++i)
        	 userwords[i] = (String)uwords[i];
        	     
	
	
	ArrayList misspell = new ArrayList();
		String str;
		int flag;
		int count=0;
		
		for(int i=0; i<userwords.length; ++i){
		        //get first user word to check for misspelling
			str = userwords[i];	
			flag=0;
			//System.out.println("str uword: " + str);
			for(int j=0; j<lwords.length; ++j){
				
				//word in dictionary
				if(str.equals(lwords[j])){
					//System.out.println("This word: "+str+" is correctly spelled");
					flag=1;
					break;
				}
				
				
			}//ends for j
			
		if(flag == 0){
		// str not in dictionary; thus misspell	
		misspell.add(str);
		System.out.println("Misspell: " + str);
		/*
		try
{
    String filename= file;
PrintWriter fw = new PrintWriter(new BufferedWriter(new FileWriter(filename, true)));
fw.println(str);//appends the string to the file
    fw.close();
}
catch(IOException ioe)
{
    System.err.println("IOException: " + ioe.getMessage());
}
*/

		}
		else { //misspell is a correct word; delete from dictionary
			System.out.println("not misspell: " + str + " file: " + file);
			avail.removeLineFromFile(file, str);
		}
	//	System.out.println("Misspelling: " + str);
		
			
		}//ends for i
		
	
		//System.out.println(" Misspell arraylist: "+ misspell);
		System.out.println (" Count : " + count);
         Object m[] = misspell.toArray(); 	
         return (m);
  }//ends check misspelling
 
     public void removeLineFromFile(String file, String lineToRemove) {

        try {

            File inFile = new File(file);
            System.out.println("File: " + file);
            
            if (!inFile.isFile()) {
                System.out.println("Parameter is not an existing file");
                return;
            }

            // Construct the new file that will later be renamed to the original
            // filename.
            File tempFile = new File(inFile.getAbsolutePath() + ".tmp");
            
            System.out.println("temp: " + tempFile);
            
            BufferedReader br = new BufferedReader(new FileReader(file));
            PrintWriter pw = new PrintWriter(new FileWriter(tempFile));

            String line = null;

            // Read from the original file and write to the new
            // unless content matches data to be removed.
            while ((line = br.readLine()) != null) {

                if (!line.trim().equals(lineToRemove)) {

                    pw.println(line);
                }
            }
            
         
            	pw.close();
                br.close();
         
            
            // Delete the original file
               if (!inFile.delete()) {
                System.out.println("Could not delete file");
                System.out.println("inFile: " + inFile);
                return;
            }

            // Rename the new file to the filename the original file had.
            if (!tempFile.renameTo(inFile))
                System.out.println("Could not rename file");

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    } 
  
public static void main (String[] args){

	// 1. check for misspelling; if in dictionary then delete it.
	String line="";
	Availability avail = new Availability();
	
	String file = args[0];
	//String file = "words.txt";
	 try{
	BufferedReader br= new BufferedReader(new FileReader(file));

    while ((line = br.readLine()) != null) {

	
	
	String misspell = line;
   
	
		
	String fileName = avail.getFileNameMisspell(misspell);
		
    Object[] a =  avail.readFile(fileName);
	
	Object[] umiss = new Object[1];
	umiss[0] = (Object) misspell;
	Object[] b = avail.CheckForMisspelling(umiss, a, fileName);
	
	}
	}catch(Exception e) {System.out.println(e);}
	 
}
		
	
}// ends class availability

