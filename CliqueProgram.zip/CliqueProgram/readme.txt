CLIQUE experimental program
The Source Code
March 2021

Author: Leena Al-Hussaini

This source code is for research purposes.

On command-line prompt:
1) To compile the java files, type the following: javac *.java
2) To run the Clique program, type the following: java clique

Clique (c) 2021