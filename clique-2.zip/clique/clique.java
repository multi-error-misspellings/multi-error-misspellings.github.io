
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class clique {
	
	public static void main (String args[]) {
	
		
		System.out.println ();
		System.out.println ();		
		System.out.println ("******** CLIQUE MULTI-ERROR SPELL CHECKER *********");
		System.out.println ();
		System.out.println ();
		System.out.println ("Select Your User Type : ");
		System.out.println ("Enter (1) for Dyslexic user ");
		System.out.println ("Enter (2) for Poor nonnative English speller ");
		System.out.println ("Enter (3) for Poor computer typist ");
		System.out.println ("Enter (4) for Exit System ");

		System.out.println ();
	// Get BufferedReader for System.in.
	
	try{

		BufferedReader in = new BufferedReader(
	    new InputStreamReader(System.in));

	// Read line from console.
	String line = in.readLine();
	
	
	      for (int i=0; i<4; ++i){
	      if (line.equals("1") || line.equals("2") || line.equals("3") ) 
	         break;
	      if (line.equals("4"))
	      	  System.exit(0);

	     
	     else if (!line.equals("1") || !line.equals("2") || !line.equals("3") || !line.equals("4")) {
		System.out.println ("Select Your User Type : ");
		System.out.println ("Enter (1) for Dyslexic user ");
		System.out.println ("Enter (2) for Poor nonnative English speller ");
		System.out.println ("Enter (3) for Poor computer typist ");
		System.out.println ("Enter (4) for Exit System ");
		
		System.out.println ();
		line = in.readLine();
			
	      }
	      else if (i == 4)
	      	  System.exit(0);
	      
	}//ends for loop
	
	
	
	String ms="";

		if (line.equals("1")) 
			{   System.out.println();
				System.out.println("Clique welcomes you, dyslexic user");
				while(!ms.equals("0")){
					
		
					for(int i=0; i < 5; ++i){
						System.out.println();
						System.out.println ("Enter your multi-error misspelling or enter 0 to exit: ");
				
						in = new BufferedReader(new InputStreamReader(System.in));

						// Read line from console.
						ms = in.readLine();
		
						if (ms.equals("")) {} 
						else if (ms.equals("0"))
							{ System.exit(0);}
	  	 
						else
						{
							System.out.println();
							System.out.println ("Your misspell is: " + ms);
							System.out.println();
							System.out.println ("Suggestions: ");
							break;
						}
	  	 
					}//ends for loop 5
	  
			
					
					
	         //run Jaro Winkler algorithm
			 RunJaro rj = new RunJaro ();
			 int code = rj.distance(ms);
				
			 if(code == 1) // i.e. misspell is a misspell
			 {// if user did not find the result
			 //run 2gram algorithm
			 System.out.println();
			 System.out.println ("Did you find the correct word in the suggestion list?");
			 System.out.println ("Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm

			 	 RunNG rn = new RunNG();
			 	 rn.distance(ms);
			 	 
			 	 System.out.println();
				 System.out.println ("Did you find the correct word in the suggestion list?");
			     System.out.println ("Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm
			 	 
			 	 RunLCS rl = new RunLCS();
			 	 rl.distance(ms);
			 	 
			 	 System.out.println();
			 	 System.out.println("If you did not find the correct word for your ");
			 	 System.out.println("misspelling, then CLIQUE can not find it as CLIQUE ");
			 	 System.out.println("executed all algorithms serving your misspelling.");


			 }		 	 
			 	 
			 	else 
			 	 System.exit(0);	 
			 	 

			 }
			 else 
			 	 System.exit(0);
			 	}// ends while loop 
				
			 	}
				
				
			}// line .equals 1
			
			
			
			
		else if (line.equals("2")) 
			{   System.out.println();
				System.out.println("Clique welcomes you, poor nonnative English speller user");
				while(!ms.equals("0")){
					
		
					for(int i=0; i < 5; ++i){
						System.out.println();
						System.out.println ("Enter your multi-error misspelling or enter 0 to exit: ");
				
						in = new BufferedReader(new InputStreamReader(System.in));

						// Read line from console.
						ms = in.readLine();
		
						if (ms.equals("")) {} 
						else if (ms.equals("0"))
							{ System.exit(0);}
	  	 
						else
						{
							System.out.println();
							System.out.println ("Your misspell is: " + ms);
							System.out.println();
							System.out.println ("Suggestions: ");
							break;
						}
	  	 
					}//ends for loop 5
	  
			
					
					
	         //run Jaro Winkler algorithm
			 RunJaro rj = new RunJaro ();
			 int code = rj.distance(ms);
				
			 if(code == 1) // i.e. misspell is a misspell
			 {// if user did not find the result
			 //run 2gram algorithm
			 System.out.println();
			 System.out.println ("Did you find the correct word in the suggestion list?");
			 System.out.println ("Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm

			 	 RunNG rn = new RunNG();
			 	 rn.distance(ms);

			 	 System.out.println();
			 	 System.out.println("If you did not find the correct word for your ");
			 	 System.out.println("misspelling, then CLIQUE can not find it as CLIQUE ");
			 	 System.out.println("executed all algorithms serving your misspelling.");			 	 
	
			 }		 	 
			 	 
			 	else 
			 	 System.exit(0);	 
			 	 

		
			 	}// ends while loop 
				
			 	}
				
				
			}// line .equals 2
						
	
	

		else if (line.equals("3")) 
		{   System.out.println();
				System.out.println("Clique welcomes you, poor computer typist user");
				while(!ms.equals("0")){
					
		
					for(int i=0; i < 5; ++i){
						System.out.println();
						System.out.println ("Enter your multi-error misspelling or enter 0 to exit: ");
				
						in = new BufferedReader(new InputStreamReader(System.in));

						// Read line from console.
						ms = in.readLine();
		
						if (ms.equals("")) {} 
						else if (ms.equals("0"))
							{ System.exit(0);}
	  	 
						else
						{
							System.out.println();
							System.out.println ("Your misspell is: " + ms);
							System.out.println();
							System.out.println ("Suggestions: ");
							break;
						}
	  	 
					}//ends for loop 5
	  
			
					
					
	         //run Jaro Winkler algorithm
			 RunHamming rh = new RunHamming();
			 int code =	 rh.distance(ms);		
				
			 if(code == 1) // i.e. misspell is a misspell
			 {// if user did not find the result
			 //run 2gram algorithm
			 System.out.println();
			 System.out.println ("Did you find the correct word in the suggestion list?");
			 System.out.println ("Type (Y) for yes and (N) for no? ");
			 
				 in = new BufferedReader(new InputStreamReader(System.in));

				 // Read line from console.
				 line = in.readLine();			 
	
			 if(line.equals("Y") || line.equals("y"))
			 	 {}
			 else if (line.equals("N") || line.equals("n"))
			 {// execute another algorithm

			 	 RunNG rn = new RunNG();
			 	 rn.distance(ms);

			 	 System.out.println();
			 	 System.out.println("If you did not find the correct word for your ");
			 	 System.out.println("misspelling, then CLIQUE can not find it as CLIQUE ");
			 	 System.out.println("executed all algorithms serving your misspelling.");	
			 }		 	 
			 	 
			 	else 
			 	 System.exit(0);	 
			 	 

		
			 	}// ends while loop 
				
			 	}
				
				
			}// line .equals 3			
			
	
			
		else if (line.equals("4")) 
			{ 
				System.exit(0);
				
			}
	
	}catch(Exception e){}
	
	
	}//ends main
}//end class